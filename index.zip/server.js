// Urna Eletrônica - servidor sem dependências (só precisa do Node.js 16+)
// Uso:  ADMIN_PASS=minhasenha node server.js     (Windows: set ADMIN_PASS=minhasenha && node server.js)
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto'), os = require('os');
const PORT = process.env.PORT || 3000;
const ADMIN_PASS = process.env.ADMIN_PASS || 'admin123';
const DB = path.join(__dirname, 'data.json');

let db = { config: { title: 'Eleição', endTime: null, open: true, blockByIp: true }, candidates: [], votes: [], voters: [] };
if (fs.existsSync(DB)) { try { db = { ...db, ...JSON.parse(fs.readFileSync(DB, 'utf8')) }; } catch (e) { console.error('data.json inválido, começando do zero'); } }
const save = () => fs.writeFileSync(DB, JSON.stringify(db, null, 2));

const sha = s => crypto.createHash('sha256').update(String(s)).digest('hex');
const send = (res, code, obj, headers = {}) => { res.writeHead(code, { 'Content-Type': 'application/json', ...headers }); res.end(JSON.stringify(obj)); };
const readBody = req => new Promise(r => { let b = ''; req.on('data', c => { b += c; if (b.length > 1e5) req.destroy(); }); req.on('end', () => { try { r(JSON.parse(b || '{}')); } catch { r({}); } }); });
const cookies = req => Object.fromEntries((req.headers.cookie || '').split(';').map(c => c.trim().split('=')).filter(c => c[0]));
const getIp = req => (req.headers['cf-connecting-ip'] || (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress || '').replace('::ffff:', '');
const isOpen = () => db.config.open && (!db.config.endTime || Date.now() < new Date(db.config.endTime).getTime());
const isAdmin = req => req.headers['x-admin-pass'] === ADMIN_PASS;

function voterInfo(req) {
  const c = cookies(req); let vid = c.vid, setCookie = {};
  if (!vid || !/^[a-f0-9]{32}$/.test(vid)) { vid = crypto.randomBytes(16).toString('hex'); setCookie = { 'Set-Cookie': `vid=${vid}; Max-Age=31536000; Path=/; HttpOnly; SameSite=Lax` }; }
  const hv = 'v:' + sha(vid), hi = 'i:' + sha(getIp(req));
  const voted = db.voters.includes(hv) || (db.config.blockByIp && db.voters.includes(hi));
  return { hv, hi, voted, setCookie };
}

function results() {
  const counts = {}; db.candidates.forEach(c => counts[c.number] = 0);
  let branco = 0, nulo = 0;
  db.votes.forEach(v => { if (v === 'branco') branco++; else if (v === 'nulo') nulo++; else if (v in counts) counts[v]++; });
  const list = db.candidates.map(c => ({ ...c, votes: counts[c.number] })).sort((a, b) => b.votes - a.votes);
  const top = list.length ? list[0].votes : 0;
  const winners = top > 0 ? list.filter(c => c.votes === top) : [];
  return { list, branco, nulo, total: db.votes.length, winners };
}

const server = http.createServer(async (req, res) => {
  const url = req.url.split('?')[0];
  try {
    if (req.method === 'GET' && (url === '/' || url === '/index.html')) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(fs.readFileSync(path.join(__dirname, 'public', 'index.html')));
    }
    if (url === '/api/state' && req.method === 'GET') {
      const v = voterInfo(req);
      return send(res, 200, { title: db.config.title, open: isOpen(), endTime: db.config.endTime, now: Date.now(), voted: v.voted,
        candidates: db.candidates }, v.setCookie);
    }
    if (url === '/api/vote' && req.method === 'POST') {
      const { number } = await readBody(req);
      const v = voterInfo(req);
      if (!isOpen()) return send(res, 403, { error: 'Votação encerrada.' }, v.setCookie);
      if (v.voted) return send(res, 403, { error: 'Você já votou.' }, v.setCookie);
      let vote;
      if (number === 'branco') vote = 'branco';
      else if (db.candidates.some(c => c.number === String(number))) vote = String(number);
      else vote = 'nulo';
      db.votes.push(vote); db.voters.push(v.hv, v.hi); save();   // o voto não fica ligado ao eleitor
      return send(res, 200, { ok: true }, v.setCookie);
    }
    // ---- ADMIN ----
    if (url.startsWith('/api/admin/')) {
      if (!isAdmin(req)) return send(res, 401, { error: 'Senha incorreta.' });
      const body = req.method === 'POST' ? await readBody(req) : {};
      if (url === '/api/admin/login') return send(res, 200, { ok: true });
      if (url === '/api/admin/data') return send(res, 200, { config: db.config, candidates: db.candidates, results: results(), now: Date.now() });
      if (url === '/api/admin/config') {
        const c = db.config;
        if (typeof body.title === 'string') c.title = body.title.slice(0, 100) || 'Eleição';
        if ('endTime' in body) c.endTime = body.endTime ? new Date(body.endTime).toISOString() : null;
        if (typeof body.open === 'boolean') c.open = body.open;
        if (typeof body.blockByIp === 'boolean') c.blockByIp = body.blockByIp;
        save(); return send(res, 200, { ok: true });
      }
      if (url === '/api/admin/candidate') {
        const number = String(body.number || '').trim(), name = String(body.name || '').trim().slice(0, 80), party = String(body.party || '').trim().slice(0, 40);
        if (!/^\d{1,5}$/.test(number)) return send(res, 400, { error: 'Número deve ter de 1 a 5 dígitos.' });
        if (!name) return send(res, 400, { error: 'Informe o nome.' });
        if (db.candidates.some(c => c.number === number)) return send(res, 400, { error: 'Esse número já existe.' });
        db.candidates.push({ number, name, party }); save(); return send(res, 200, { ok: true });
      }
      if (url === '/api/admin/candidate/delete') { db.candidates = db.candidates.filter(c => c.number !== String(body.number)); save(); return send(res, 200, { ok: true }); }
      if (url === '/api/admin/reset') { if (body.confirm !== 'ZERAR') return send(res, 400, { error: 'Confirmação inválida.' }); db.votes = []; db.voters = []; save(); return send(res, 200, { ok: true }); }
    }
    send(res, 404, { error: 'Não encontrado' });
  } catch (e) { console.error(e); send(res, 500, { error: 'Erro interno' }); }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('\n=== URNA ELETRÔNICA ===');
  console.log('Neste PC:      http://localhost:' + PORT);
  Object.values(os.networkInterfaces()).flat().filter(i => i.family === 'IPv4' && !i.internal).forEach(i => console.log('Na sua rede:   http://' + i.address + ':' + PORT));
  console.log('Senha do admin: ' + (process.env.ADMIN_PASS ? '(a que você definiu)' : 'admin123  <-- TROQUE com ADMIN_PASS'));
  console.log('Botão secreto: canto inferior direito da tela.\n');
});
